function setConfig(str) {
  console.log('In javascript lti')
  var config = JSON.parse(str)
  console.log(config)

}
